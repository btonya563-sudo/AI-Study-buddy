import { Router } from 'express'
import { adminOnly, protect } from '../middleware/auth.js'
import { aiUsage, deleteUser, logs, statistics, updateUser, userDetails, users } from '../controllers/adminController.js'
const router = Router()
router.use(protect, adminOnly)
router.get('/users', users)
router.get('/users/:id', userDetails)
router.put('/users/:id', updateUser)
router.delete('/users/:id', deleteUser)
router.get('/statistics', statistics)
router.get('/ai-usage', aiUsage)
router.get('/activity-logs', logs)
export default router
