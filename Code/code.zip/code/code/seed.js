import 'dotenv/config'
import mongoose from 'mongoose'
import User from './src/models/User.js'
import { connectDB } from './src/config/db.js'

await connectDB()
const email = process.env.ADMIN_EMAIL || 'admin@example.com'
const existing = await User.findOne({ email })
if (existing) console.log('Admin already exists')
else { await User.create({ name: process.env.ADMIN_NAME || 'System Administrator', email, password: process.env.ADMIN_PASSWORD || 'change-this-password', role: 'Admin' }); console.log(`Admin created: ${email}`) }
await mongoose.disconnect()
