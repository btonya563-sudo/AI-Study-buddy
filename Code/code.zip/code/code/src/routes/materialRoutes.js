import { Router } from 'express'
import { createMaterial, deleteMaterial, getMaterial, listMaterials, updateMaterial } from '../controllers/materialController.js'
import { protect } from '../middleware/auth.js'
import { upload } from '../middleware/upload.js'
const router = Router()
router.use(protect)
router.post('/upload', upload.single('file'), createMaterial)
router.get('/', listMaterials)
router.get('/:id', getMaterial)
router.put('/:id', updateMaterial)
router.delete('/:id', deleteMaterial)
export default router
