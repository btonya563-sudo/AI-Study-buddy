import { GoogleGenAI } from '@google/genai'

const fallback = (type, content) => {
  const clean = content.trim().replace(/\s+/g, ' ')
  if (type === 'summary') return { summary: clean ? `${clean.slice(0, 420)}${clean.length > 420 ? '...' : ''}` : 'Add content to generate a focused summary.', points: ['Review the core definitions', 'Connect the ideas to a practical example', 'Test your recall without notes'] }
  if (type === 'flashcards') return [{ question: 'What is the central idea?', answer: clean.slice(0, 180) || 'Add content to generate an answer.' }, { question: 'How would you explain this to a peer?', answer: 'Use a simple definition, one example, and one implication.' }]
  return { questions: [{ question: 'What should you focus on first?', options: ['Core concepts', 'Unrelated details', 'Skipping practice', 'Memorizing without context'], correctAnswer: 'Core concepts' }] }
}

export async function generateStructured(type, prompt, content = '') {
  if (!process.env.GEMINI_API_KEY) return fallback(type, content)
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY })
  const schemas = {
    summary: '{"summary":"string","points":["string"]}',
    flashcards: '[{"question":"string","answer":"string"}]',
    quiz: '{"questions":[{"question":"string","options":["string","string","string","string"],"correctAnswer":"string"}]}'
  }
  const response = await ai.models.generateContent({ model: 'gemini-3.6-flash', contents: `${prompt}\nReturn only valid JSON matching this shape: ${schemas[type]}` })
  return JSON.parse(response.text.replace(/^```json\s*|\s*```$/g, ''))
}

export async function generateText(prompt) {
  if (!process.env.GEMINI_API_KEY) return 'AI assistant is ready. Add GEMINI_API_KEY to enable live Gemini responses.'
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY })
  const response = await ai.models.generateContent({ model: 'gemini-3.6-flash', contents: prompt })
  return response.text
}
