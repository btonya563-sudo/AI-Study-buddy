import { Router } from 'express'
import { chat, flashcards, quiz, studyPlan, summarize } from '../controllers/aiController.js'
import { protect } from '../middleware/auth.js'
const router = Router()
router.use(protect)
router.post('/materials/:id/summarize', summarize)
router.post('/flashcards', flashcards)
router.post('/quiz', quiz)
router.post('/study-plan', studyPlan)
router.post('/chat', chat)
export default router
