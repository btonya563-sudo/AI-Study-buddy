import User from '../models/User.js'
import ActivityLog from '../models/ActivityLog.js'
import { generateToken, publicUser } from '../utils/generateToken.js'

export async function register(req, res, next) {
  try {
    const { name, email, password } = req.body
    if (!name || !email || !password || password.length < 8) return res.status(400).json({ success: false, message: 'Name, valid email and an 8-character password are required' })
    const exists = await User.findOne({ email: email.toLowerCase() })
    if (exists) return res.status(409).json({ success: false, message: 'Email is already registered' })
    const user = await User.create({ name, email, password })
    await ActivityLog.create({ userId: user._id, action: 'registration', description: 'New student account created' })
    res.status(201).json({ success: true, message: 'Account created', data: { user: publicUser(user), token: generateToken(user) } })
  } catch (error) { next(error) }
}

export async function login(req, res, next) {
  try {
    const { email, password } = req.body
    const user = await User.findOne({ email: email?.toLowerCase() }).select('+password')
    if (!user || !user.isActive || !(await user.comparePassword(password || ''))) return res.status(401).json({ success: false, message: 'Invalid email or password' })
    await ActivityLog.create({ userId: user._id, action: 'login', description: 'User signed in' })
    res.json({ success: true, message: 'Welcome back', data: { user: publicUser(user), token: generateToken(user) } })
  } catch (error) { next(error) }
}

export function me(req, res) { res.json({ success: true, message: 'Current user', data: { user: publicUser(req.user) } }) }
