import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  action: { type: String, required: true },
  description: String,
  status: { type: String, default: 'success' }
}, { timestamps: true })

export default mongoose.model('ActivityLog', schema)
