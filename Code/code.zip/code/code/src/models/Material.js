import mongoose from 'mongoose'

const materialSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true, trim: true },
  subject: { type: String, required: true, trim: true },
  content: { type: String, default: '' },
  filePath: String
}, { timestamps: true })

export default mongoose.model('StudyMaterial', materialSchema)
