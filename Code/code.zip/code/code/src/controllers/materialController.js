import Material from '../models/Material.js'
import ActivityLog from '../models/ActivityLog.js'

export async function listMaterials(req, res, next) {
  try { res.json({ success: true, message: 'Materials loaded', data: await Material.find({ userId: req.user._id }).sort('-updatedAt') }) } catch (error) { next(error) }
}
export async function getMaterial(req, res, next) {
  try {
    const material = await Material.findOne({ _id: req.params.id, userId: req.user._id })
    if (!material) return res.status(404).json({ success: false, message: 'Material not found' })
    res.json({ success: true, message: 'Material loaded', data: material })
  } catch (error) { next(error) }
}
export async function createMaterial(req, res, next) {
  try {
    const { title, subject, content = '' } = req.body
    if (!title || !subject) return res.status(400).json({ success: false, message: 'Title and subject are required' })
    const material = await Material.create({ userId: req.user._id, title, subject, content, filePath: req.file?.path })
    await ActivityLog.create({ userId: req.user._id, action: 'material_upload', description: `Added ${title}` })
    res.status(201).json({ success: true, message: 'Material saved', data: material })
  } catch (error) { next(error) }
}
export async function updateMaterial(req, res, next) {
  try {
    const material = await Material.findOneAndUpdate({ _id: req.params.id, userId: req.user._id }, req.body, { new: true, runValidators: true })
    if (!material) return res.status(404).json({ success: false, message: 'Material not found' })
    res.json({ success: true, message: 'Material updated', data: material })
  } catch (error) { next(error) }
}
export async function deleteMaterial(req, res, next) {
  try {
    const material = await Material.findOneAndDelete({ _id: req.params.id, userId: req.user._id })
    if (!material) return res.status(404).json({ success: false, message: 'Material not found' })
    res.json({ success: true, message: 'Material deleted', data: null })
  } catch (error) { next(error) }
}
