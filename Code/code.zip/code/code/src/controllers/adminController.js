import User from '../models/User.js'
import Material from '../models/Material.js'
import Summary from '../models/Summary.js'
import Flashcard from '../models/Flashcard.js'
import Quiz from '../models/Quiz.js'
import StudyPlan from '../models/StudyPlan.js'
import ActivityLog from '../models/ActivityLog.js'

export async function statistics(_req, res, next) { try { const [users, activeUsers, materials, summaries, flashcards, quizzes, plans] = await Promise.all([User.countDocuments(), User.countDocuments({ isActive: true }), Material.countDocuments(), Summary.countDocuments(), Flashcard.countDocuments(), Quiz.countDocuments(), StudyPlan.countDocuments()]); res.json({ success: true, message: 'Statistics loaded', data: { users, activeUsers, materials, summaries, flashcards, quizzes, plans, aiRequests: summaries + flashcards + quizzes + plans } }) } catch (error) { next(error) } }
export async function users(req, res, next) { try { const query = req.query.search ? { $or: [{ name: new RegExp(req.query.search, 'i') }, { email: new RegExp(req.query.search, 'i') }] } : {}; res.json({ success: true, message: 'Users loaded', data: await User.find(query).sort('-createdAt') }) } catch (error) { next(error) } }
export async function userDetails(req, res, next) { try { const user = await User.findById(req.params.id).select('-password'); if (!user) return res.status(404).json({ success: false, message: 'User not found' }); res.json({ success: true, message: 'User loaded', data: user }) } catch (error) { next(error) } }
export async function updateUser(req, res, next) { try { const user = await User.findByIdAndUpdate(req.params.id, { name: req.body.name, role: req.body.role, isActive: req.body.isActive }, { new: true }).select('-password'); if (!user) return res.status(404).json({ success: false, message: 'User not found' }); res.json({ success: true, message: 'User updated', data: user }) } catch (error) { next(error) } }
export async function deleteUser(req, res, next) { try { if (String(req.user._id) === req.params.id) return res.status(400).json({ success: false, message: 'You cannot delete your own account' }); await User.findByIdAndDelete(req.params.id); res.json({ success: true, message: 'User deleted', data: null }) } catch (error) { next(error) } }
export async function logs(_req, res, next) { try { res.json({ success: true, message: 'Activity loaded', data: await ActivityLog.find().populate('userId', 'name email').sort('-createdAt').limit(100) }) } catch (error) { next(error) } }
export async function aiUsage(_req, res, next) { try { const actions = await ActivityLog.aggregate([{ $match: { action: { $in: ['summary_generation', 'flashcard_generation', 'quiz_generation', 'study_plan_generation'] } } }, { $group: { _id: '$action', count: { $sum: 1 } } }]); res.json({ success: true, message: 'AI usage loaded', data: actions }) } catch (error) { next(error) } }
