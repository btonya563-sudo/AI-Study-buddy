import Material from '../models/Material.js'
import Summary from '../models/Summary.js'
import Flashcard from '../models/Flashcard.js'
import Quiz from '../models/Quiz.js'
import StudyPlan from '../models/StudyPlan.js'
import ActivityLog from '../models/ActivityLog.js'
import { generateStructured, generateText } from '../services/gemini.js'

async function ownedMaterial(userId, id) {
  const material = await Material.findOne({ _id: id, userId })
  if (!material) { const error = new Error('Material not found'); error.statusCode = 404; throw error }
  return material
}
export async function summarize(req, res, next) {
  try { const m = await ownedMaterial(req.user._id, req.params.id); const result = await generateStructured('summary', `Summarize this study material for a student.\n${m.content}`, m.content); const saved = await Summary.create({ userId: req.user._id, materialId: m._id, ...result }); await ActivityLog.create({ userId: req.user._id, action: 'summary_generation', description: m.title }); res.json({ success: true, message: 'Summary generated', data: saved }) } catch (error) { next(error) }
}
export async function flashcards(req, res, next) {
  try { const m = await ownedMaterial(req.user._id, req.body.materialId); const result = await generateStructured('flashcards', `Create useful question and answer flashcards from this material:\n${m.content}`, m.content); const cards = await Flashcard.insertMany(result.map(card => ({ ...card, userId: req.user._id, materialId: m._id }))); await ActivityLog.create({ userId: req.user._id, action: 'flashcard_generation', description: m.title }); res.json({ success: true, message: 'Flashcards generated', data: cards }) } catch (error) { next(error) }
}
export async function quiz(req, res, next) {
  try { const m = await ownedMaterial(req.user._id, req.body.materialId); const result = await generateStructured('quiz', `Create a multiple-choice quiz from this material:\n${m.content}`, m.content); const saved = await Quiz.create({ userId: req.user._id, materialId: m._id, questions: result.questions }); await ActivityLog.create({ userId: req.user._id, action: 'quiz_generation', description: m.title }); res.json({ success: true, message: 'Quiz generated', data: saved }) } catch (error) { next(error) }
}
export async function studyPlan(req, res, next) {
  try { const { subject, examDate, hours, level, goal, preferredTime } = req.body; if (!subject || !examDate) return res.status(400).json({ success: false, message: 'Subject and exam date are required' }); const result = await generateStructured('summary', `Create a study plan for ${subject}, exam date ${examDate}, ${hours} hours/day, level ${level}, goal ${goal}, preferred time ${preferredTime}.`, subject); const plan = [{ day: 1, topic: result.points?.[0] || 'Core concepts', duration: `${hours || 1} hours`, tasks: result.points || ['Review the topic', 'Practice recall'] }]; const saved = await StudyPlan.create({ userId: req.user._id, subject, examDate, studyPlan: plan }); await ActivityLog.create({ userId: req.user._id, action: 'study_plan_generation', description: subject }); res.json({ success: true, message: 'Study plan generated', data: saved }) } catch (error) { next(error) }
}
export async function chat(req, res, next) { try { const answer = await generateText(`Answer this educational question clearly for a student: ${req.body.message}`); res.json({ success: true, message: 'Response generated', data: { answer } }) } catch (error) { next(error) } }
