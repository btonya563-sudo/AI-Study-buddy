import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  materialId: { type: mongoose.Schema.Types.ObjectId, ref: 'StudyMaterial', required: true },
  questions: [{ question: String, options: [String], correctAnswer: String }]
}, { timestamps: true })

export default mongoose.model('Quiz', schema)
