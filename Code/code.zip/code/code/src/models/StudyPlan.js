import mongoose from 'mongoose'

const schema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  subject: { type: String, required: true },
  examDate: Date,
  studyPlan: [{ day: Number, topic: String, duration: String, tasks: [String] }]
}, { timestamps: true })

export default mongoose.model('StudyPlan', schema)
