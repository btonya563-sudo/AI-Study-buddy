import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import path from 'path'
import { connectDB } from './src/config/db.js'
import authRoutes from './src/routes/authRoutes.js'
import materialRoutes from './src/routes/materialRoutes.js'
import aiRoutes from './src/routes/aiRoutes.js'
import adminRoutes from './src/routes/adminRoutes.js'
import { errorHandler } from './src/middleware/errorHandler.js'

const app = express()
app.use(cors())
app.use(express.json({ limit: '2mb' }))
app.use('/uploads', express.static(path.resolve('uploads')))
app.get('/api/health', (_req, res) => res.json({ success: true, message: 'AI StudyBuddy API is running', data: null }))
app.use('/api/auth', authRoutes)
app.use('/api/material', materialRoutes)
app.use('/api/ai', aiRoutes)
app.use('/api', aiRoutes)
app.use('/api/admin', adminRoutes)
app.use(errorHandler)

const port = process.env.PORT || 5000
connectDB().then(() => app.listen(port, () => console.log(`API listening on http://localhost:${port}`))).catch(error => { console.error('Database connection failed', error); process.exit(1) })
